package algorithms.implementation;

import algorithms.dependents.btree.BTree;

public class BTreeImpl {

    public static void main(String[] args) {

        BTree<Character, Integer> bTree = new BTree<>();

        String name = "victoriaeuu";

        for (int i = 0; i < name.length(); i++) {
            char letra = name.charAt(i);
            bTree.put(letra, i); 
        }

        System.out.println(bTree);
    }
}

// Victoria Carolina Ferreira da Silva

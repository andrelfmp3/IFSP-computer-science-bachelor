package algorithms.implementation;

import algorithms.dependents.trie.Trie;

public class TrieImpl {

    public static void main(String[] args) {

        Trie<Integer> trie = new Trie<>();

        trie.put("vick", 1);
        trie.put("vickvick", 2);
        trie.put("euzinha", 3);

        System.out.println("Tamanho: " + trie.getSize());

        System.out.println("Busca: " + trie.get("vick"));
        System.out.println("Busca: " + trie.get("vickvick"));
        System.out.println("Busca: " + trie.get("euzinha"));

        System.out.println("Todas chaves:");
        for (String key : trie.getKeys()) {
            System.out.println(key);
        }
    }
}

// Victoria Carolina Ferreira da Silva

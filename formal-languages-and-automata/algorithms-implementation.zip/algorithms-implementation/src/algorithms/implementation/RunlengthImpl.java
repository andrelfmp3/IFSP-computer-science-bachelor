package algorithms.implementation;

import algorithms.dependents.runlenght.RunLength;

public class RunlengthImpl {

    public static void main(String[] args) { // rever com andre
      
        System.out.println("Executando compressão");
        RunLength.compress();

        System.out.println("Executando expansão");
        RunLength.expand();
    }

}

// Victoria Carolina Ferreira da Silva

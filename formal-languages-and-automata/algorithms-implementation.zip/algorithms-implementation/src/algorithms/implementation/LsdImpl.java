package algorithms.implementation;

import algorithms.dependents.lsd.LSD;

public class LsdImpl {

    public static void main(String[] args) {

        String[] arr = {
            "qwe",
            "ewq",
            "weq",
            "wqr",
            "eew",
            "qwe"
        };

        int w = arr[0].length();

        System.out.println("Antes de ordenar:");
        for (String s : arr) {
            System.out.println(s);
        }

        LSD.sort(arr, w);

        System.out.println("\nDepois de ordenar:");
        for (String s : arr) {
            System.out.println(s);
        }

    }

}

// Victoria Carolina Ferreira da Silva


package algorithms.implementation;

import algorithms.dependents.lzw.LZW;

public class LzwImpl {

    public static void main(String[] args) { // rever com andre depois (apenas mostra que funciona)
        
        System.out.println("Comprimindo");
        LZW.compress();
        
        System.out.println("Expandindo");
        LZW.expand();
        
    }
    
}

// Victoria Carolina Ferreira da Silva


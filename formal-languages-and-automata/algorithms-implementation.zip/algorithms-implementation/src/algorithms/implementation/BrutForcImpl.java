package algorithms.implementation;

import algorithms.dependents.brutForc.BoyerMoore;

public class BrutForcImpl {

    public static void main(String[] args) {

        String a = "vick";
        BoyerMoore bm = new BoyerMoore(a);
    
        String b = "eueueuvickeuvick";


        int posicao = bm.search(b);

        if (posicao < b.length()) {
            System.out.println("Padrao \"" + a + "\" encontrado na posicao: " + posicao);
        } else {
            System.out.println("Padrao \"" + a + "\" nao encontrado no texto.");
        }
    }
}

// Victoria Carolina Ferreira da Silva


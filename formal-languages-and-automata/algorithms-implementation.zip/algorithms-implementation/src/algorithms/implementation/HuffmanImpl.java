package algorithms.implementation;

import algorithms.dependents.hufman.Huffman;

public class HuffmanImpl { // rever com o andre depois

    public static void main(String[] args) {
        
        if ("compress".equalsIgnoreCase(args[0])) {
            Huffman.compress();
        } else if ("expand".equalsIgnoreCase(args[0])) {
            Huffman.expand();
        }
    }
}

// Victoria Carolina Ferreira da Silva

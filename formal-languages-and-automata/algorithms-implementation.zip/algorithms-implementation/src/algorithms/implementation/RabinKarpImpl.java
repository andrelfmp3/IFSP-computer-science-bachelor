package algorithms.implementation;

import algorithms.dependents.rabinkarp.RabinKarp;

public class RabinKarpImpl {

    public static void main(String[] args) {
        
        String texto = "eusouavick";
        String padrao = "vick";

        RabinKarp rk = new RabinKarp(padrao);
        int pos = rk.search(texto);

        if (pos < texto.length()) {
            System.out.println("Padrao encontrado em: " + pos);
        } else {
            System.out.println("Sem padrao.");
        }
        
    }
    
}

// Victoria Carolina Ferreira da Silva

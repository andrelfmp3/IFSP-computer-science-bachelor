package algorithms.implementation;

import algorithms.dependents.kmp.KMP;

public class KmpImpl {

    public static void main(String[] args) {

        String completo = "EUVICKCAROLINAEUEUEU";
        String padrao = "VICK";

        KMP kmp = new KMP(padrao);
        int posicao = kmp.search(completo);

        if (posicao == completo.length()) {
            System.out.println("Padrao nao encotrado.");
        } else {
            System.out.println("Padrao encontrado em: " + posicao);
        }

    }

}

// Victoria Carolina Ferreira da Silva

package algorithms.implementation;

import algorithms.dependents.avl.AVLTree;

public class AVLImpl { 
    
    public static void main(String[] args) {
        
        AVLTree<Character, Integer> avlTree = new AVLTree<>();

        String name = "victoriaa";

        for (int i = 0; i < name.length(); i++) {
            char letra = name.charAt(i);
            avlTree.put(letra, i); 
        }

        System.out.println(avlTree);
    }
}

// Victoria Carolina Ferreira da Silva

package algorithms.implementation;

import algorithms.dependents.msd.MSD;

public class MsdImp {
    
    public static void main(String[] args) {
        
        String[] palavras = {
            "draculaura",
            "batman",
            "rosa",
            "dark",
            "wandinha",
            "andré",
            "dormir"
        };
        
        System.out.println("Antes de ordenar:");
        for (String palavra : palavras) {
            System.out.println(palavra);
        }
        
        MSD.sort(palavras);
        
        System.out.println("\nDepois d ordenar:");
        for (String palavra : palavras) {
            System.out.println(palavra);
        }
        
    }
    
}

// Victoria Carolina Ferreira da Silva

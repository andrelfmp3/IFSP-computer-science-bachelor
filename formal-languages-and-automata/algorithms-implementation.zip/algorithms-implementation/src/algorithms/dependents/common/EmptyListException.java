package algorithms.dependents.common;

/**
 * Exceção para indicar lista vazia.
 * 
 * @author Prof. Dr. David Buzatto
 */
public class EmptyListException extends RuntimeException {
    
}
package algorithms.dependents.avl;

public enum TraversalTypes {
    PREORDER,
    INORDER,
    POSTORDER,
    LEVEL_ORDER
}